# Control to print all 13 digits
options(digits = 13)

# Load the necessary libraries
library(gbm)

# Specify location of the analysis folder
analysisFolder = 'C:\\Users\\dishaw\\Downloads\\edmproddemo\\Fleet\\Models\\R\\'
analysisPrefix = 'fleet_gbm'

# Specify location of the JSON folder
jsonFolder = 'C:\\Users\\dishaw\\Downloads\\edmproddemo\\Fleet\\Models\\R\\GBM\\'

# Specify location of the custom source folder
sourceFolder = 'C:\\Users\\dishaw\\Documents\\'

# Bring in custom codes for exporting model
source(paste(sourceFolder, 'export_binary_model.r', sep = ''))

# Read the CSV data
inputData <- read.table(paste(analysisFolder, 'FLEET_TRAIN2.csv', sep = ''), header = TRUE, sep = ',')

# Specify the target variables, the nominal predictors, and the interval predictors
targetVar <- 'Maintenance_flag'
intervalVars <- c('Speed_sensor', 'Vibration', 'Engine_Load', 'Coolant_Temp', 'Intake_Pressure',
                  'Engine_RPM', 'Speed_OBD', 'Intake_Air', 'Flow_Rate', 'Throttle_Pos', 'Voltage',
                  'Ambient', 'Accel', 'Engine_Oil_Temp', 'Speed_GPS', 'GPS_Longitude', 'GPS_Latitude',
                  'GPS_Bearing', 'GPS_Altitude', 'Turbo_Boost', 'Trip_Distance', 'Litres_Per_km',
                  'Accel_Ssor_Total', 'CO2', 'Trip_Time')

myvars <- c(targetVar, intervalVars)

# Threshold for the misclassification error
threshPredProb <- mean(inputData[[targetVar]], na.rm = TRUE)
print(paste('Observed Probability that ', targetVar, '= 1 is', threshPredProb))

# Remove all missing observations
trainData <- na.omit(inputData[myvars], na.action = 'exclude')

# A Gradient Boosting Machine on a Logistic model
# -- target must be a numeric variable with values 0 and 1
# -- maximum number of trees is 100
# -- maximum depth of each tree is 2
# -- all fields, except Maintenance_flag, in trainData are predictors

maxNTrees = 100
maxDepth = 2
set.seed(20200730)

myGBM <- gbm(formula = Maintenance_flag ~ Speed_sensor + Vibration + Engine_Load + Coolant_Temp
             + Intake_Pressure + Engine_RPM + Speed_OBD + Intake_Air + Flow_Rate + Throttle_Pos
             + Voltage + Ambient + Accel + Engine_Oil_Temp + Speed_GPS + GPS_Longitude + GPS_Latitude
             + GPS_Bearing + GPS_Altitude + Turbo_Boost + Trip_Distance + Litres_Per_km + Accel_Ssor_Total
             + CO2 + Trip_Time,
             distribution = 'bernoulli', data = trainData,
             n.trees = maxNTrees, interaction.depth = maxDepth,
             keep.data = TRUE, verbose = TRUE)

print(myGBM)

# See the model fit summary
print(summary(myGBM))

# Calculate the prediction and save then to an external CSV file

c <- trainData[1,]

typeof(c)

p <- predict(myGBM, newdata = trainData[1,], n.trees = maxNTrees, type = 'response')
r <- ifelse(p >= threshPredProb, 1, 0)

# See the Misclassification Rate of the training data
fitted.prob <- predict(myGBM, newdata = trainData, n.trees = maxNTrees, type = 'response')
fitted.results <- ifelse(fitted.prob >= threshPredProb, 1, 0)

# Save the predictions to CSV
write.csv(cbind(trainData, fitted.prob, fitted.results), paste(jsonFolder, analysisPrefix, '_r_pred.csv', sep = ''))

# Types of the columns
typeOfColumn <- as.data.frame(do.call(rbind, lapply(inputData, typeof)))
print(typeOfColumn)

# Invoke this function to generate the zip package
export_binary_model (
    targetVar = targetVar,
    intervalVars = intervalVars,
    nominalVars = NULL,
    nominalVarsLength = NULL,
    typeOfColumn = typeOfColumn,
    targetValue = trainData[[targetVar]],
    eventValue = 1,
    predEventProb = fitted.prob,
    eventProbThreshold = threshPredProb,
    algorithmCode = 4,
    modelObject = myGBM,
    analysisFolder = analysisFolder,
    analysisPrefix = analysisPrefix,
    jsonFolder = jsonFolder,
    analysisName = 'Truck Fleet Maintenance',
    analysisDescription = paste('Gradient Boosting: n.trees =', maxNTrees, 'interaction.depth =', maxDepth, sep = ' '),
    lenOutClass = 1,
    qDebug = 'Y')

# THE END
