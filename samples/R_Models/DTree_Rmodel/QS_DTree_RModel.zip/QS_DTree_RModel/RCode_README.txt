Language: R
Version: 4.4.1
 
Packages used to generate model registration files:
sasctl 0.7.4
  Dependencies:
    jsonlie 1.8.9
    httr 1.4.7
    uuid 1.2.1
    furrr 0.3.1
    ROCR 1.0.11
    reshape 1.4.4
    base64enc 0.1.3
    dplyr 1.1.4
    glue 1.8.0
 
