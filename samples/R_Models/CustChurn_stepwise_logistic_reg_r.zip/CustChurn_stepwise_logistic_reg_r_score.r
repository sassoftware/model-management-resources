
rScoreFunction <- function(lifetime_value,avg_arpu_3m,acct_age,billing_cycle,Est_HH_Income,cs_med_home_value,cs_pct_home_owner,
                  forecast_region,data_device_age,equip_age,delinq_indicator,avg_days_susp,calls_in_pk,calls_in_offpk,
                  calls_out_offpk,calls_out_pk,mou_total_pct_MOM,voice_tot_bill_mou_curr,tot_voice_chrgs_curr,
                  bill_data_usg_m03,bill_data_usg_m06,bill_data_usg_m09,mb_data_usg_m01,mb_data_usg_m02,mb_data_usg_m03,
                  mb_data_ndist_mo6m,mb_data_usg_roamm01,mb_data_usg_roamm02,mb_data_usg_roamm03,data_usage_amt,
                  data_prem_chrgs_curr,nbr_data_cdrs,avg_data_chrgs_3m,avg_data_prem_chrgs_3m,avg_overage_chrgs_3m,
                  calls_TS_acct,wrk_orders,days_openwrkorders,calls_care_acct,calls_care_3mavg_acct,calls_care_6mavg_acct,
                  res_calls_3mavg_acct,res_calls_6mavg_acct,curr_days_susp,pymts_late_ltd,calls_care_ltd,MB_Data_Usg_M04,
                  MB_Data_Usg_M05,MB_Data_Usg_M06,MB_Data_Usg_M07,MB_Data_Usg_M08,MB_Data_Usg_M09,nbr_contacts)
{
  #Output: EM_EVENTPROBABILITY, EM_CLASSIFICATION, R_FUNC_ELAPSED
  
  # Measure execution time of this function
  start_time <- Sys.time()
  
  # Load the R model object if necessary
  if (!exists("myLogistic"))
  {
    assign("myLogistic", readRDS(file = paste(rdsPath, 'CustChurn_stepwise_logistic_reg_r.rds', sep = '')), envir = .GlobalEnv)
  }
  
  # Threshold for the misclassification error
  threshPredProb <- 0.12255479613481
  
  input_array <- data.frame('lifetime_value'=lifetime_value,'avg_arpu_3m'=avg_arpu_3m,'acct_age'=acct_age,'billing_cycle'=billing_cycle,
                            'Est_HH_Income'=Est_HH_Income,'cs_med_home_value'=cs_med_home_value,'cs_pct_home_owner'=cs_pct_home_owner,
                            'forecast_region'=forecast_region,'data_device_age'=data_device_age,'equip_age'=equip_age,'delinq_indicator'=delinq_indicator,
                            'avg_days_susp'=avg_days_susp,'calls_in_pk'=calls_in_pk,'calls_in_offpk'=calls_in_offpk,'calls_out_offpk'=calls_out_offpk,
                            'calls_out_pk'=calls_out_pk,'mou_total_pct_MOM'=mou_total_pct_MOM,'voice_tot_bill_mou_curr'=voice_tot_bill_mou_curr,
                            'tot_voice_chrgs_curr'=tot_voice_chrgs_curr,'bill_data_usg_m03'=bill_data_usg_m03,'bill_data_usg_m06'=bill_data_usg_m06,
                            'bill_data_usg_m09'=bill_data_usg_m09,'mb_data_usg_m01'=mb_data_usg_m01,'mb_data_usg_m02'=mb_data_usg_m02,'mb_data_usg_m03'=mb_data_usg_m03,
                            'mb_data_ndist_mo6m'=mb_data_ndist_mo6m,'mb_data_usg_roamm01'=mb_data_usg_roamm01,'mb_data_usg_roamm02'=mb_data_usg_roamm02,
                            'mb_data_usg_roamm03'=mb_data_usg_roamm03,'data_usage_amt'=data_usage_amt,'data_prem_chrgs_curr'=data_prem_chrgs_curr,
                            'nbr_data_cdrs'=nbr_data_cdrs,'avg_data_chrgs_3m'=avg_data_chrgs_3m,'avg_data_prem_chrgs_3m'=avg_data_prem_chrgs_3m,
                            'avg_overage_chrgs_3m'=avg_overage_chrgs_3m,'calls_TS_acct'=calls_TS_acct,'wrk_orders'=wrk_orders,'days_openwrkorders'=days_openwrkorders,
                            'calls_care_acct'=calls_care_acct,'calls_care_3mavg_acct'=calls_care_3mavg_acct,'calls_care_6mavg_acct'=calls_care_6mavg_acct,
                            'res_calls_3mavg_acct'=res_calls_3mavg_acct,'res_calls_6mavg_acct'=res_calls_6mavg_acct,'curr_days_susp'=curr_days_susp,
                            'pymts_late_ltd'=pymts_late_ltd,'calls_care_ltd'=calls_care_ltd,'MB_Data_Usg_M04'=MB_Data_Usg_M04,'MB_Data_Usg_M05'=MB_Data_Usg_M05,
                            'MB_Data_Usg_M06'=MB_Data_Usg_M06,'MB_Data_Usg_M07'=MB_Data_Usg_M07,'MB_Data_Usg_M08'=MB_Data_Usg_M08,'MB_Data_Usg_M09'=MB_Data_Usg_M09,
                            'nbr_contacts'=nbr_contacts)
  
  predProb <- predict(myLogistic, newdata = input_array, type = 'response')
  
  # Retrieve the event probability and determine the predicted target category
  if (!is.na(predProb))
  {
    EM_EVENTPROBABILITY = predProb
    EM_CLASSIFICATION <- ifelse(EM_EVENTPROBABILITY >= threshPredProb, '1', '0')
  }
  else
  {
    EM_EVENTPROBABILITY <- NA
    EM_CLASSIFICATION <- ' '
  }
  
  # Measure execution time of this function
  end_time <- Sys.time()
  elapsed_second <- end_time - start_time
  
  output_list <- list('EM_EVENTPROBABILITY' = EM_EVENTPROBABILITY, 'EM_CLASSIFICATION' = EM_CLASSIFICATION,
                      'R_FUNC_ELAPSED' = elapsed_second[[1]])
  return(output_list)
}
