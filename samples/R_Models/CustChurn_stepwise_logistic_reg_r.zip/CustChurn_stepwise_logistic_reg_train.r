# Control to print all 13 digits
options(digits = 13)

# Load the necessary libraries

# Specify location of the analysis folder
analysisFolder = 'C:\\Users\\dishaw\\Downloads\\edmproddemo\\CustomerChurn2019\\R\\'
analysisPrefix = 'CustChurn_stepwise_logistic_reg'

# Specify location of the JSON folder
jsonFolder = 'C:\\Users\\dishaw\\Downloads\\edmproddemo\\CustomerChurn2019\\R\\'

# Specify location of the custom source folder
sourceFolder = 'C:\\Users\\dishaw\\Documents\\'

# Bring in custom codes for exporting model
source(paste(sourceFolder, 'export_binary_model.r', sep = ''))

# Read the CSV data
inputData <- read.table(paste(analysisFolder, 'CUSTOMERCHURN2019.csv', sep = ''), header = TRUE, sep = ',')

# Specify the target variables, the nominal predictors, and the interval predictors
targetVar <- 'churn'
intervalVars <- c('lifetime_value','avg_arpu_3m','acct_age','billing_cycle','Est_HH_Income','cs_med_home_value','cs_pct_home_owner',
                  'forecast_region','data_device_age','equip_age','delinq_indicator','avg_days_susp','calls_in_pk','calls_in_offpk',
                  'calls_out_offpk','calls_out_pk','mou_total_pct_MOM','voice_tot_bill_mou_curr','tot_voice_chrgs_curr',
                  'bill_data_usg_m03','bill_data_usg_m06','bill_data_usg_m09','mb_data_usg_m01','mb_data_usg_m02','mb_data_usg_m03',
                  'mb_data_ndist_mo6m','mb_data_usg_roamm01','mb_data_usg_roamm02','mb_data_usg_roamm03','data_usage_amt',
                  'data_prem_chrgs_curr','nbr_data_cdrs','avg_data_chrgs_3m','avg_data_prem_chrgs_3m','avg_overage_chrgs_3m',
                  'calls_TS_acct','wrk_orders','days_openwrkorders','calls_care_acct','calls_care_3mavg_acct','calls_care_6mavg_acct',
                  'res_calls_3mavg_acct','res_calls_6mavg_acct','curr_days_susp','pymts_late_ltd','calls_care_ltd','MB_Data_Usg_M04',
                  'MB_Data_Usg_M05','MB_Data_Usg_M06','MB_Data_Usg_M07','MB_Data_Usg_M08','MB_Data_Usg_M09','nbr_contacts')

myvars <- c(targetVar, intervalVars)

# Threshold for the misclassification error
threshPredProb <- mean(inputData[[targetVar]], na.rm = TRUE)
print(paste('Observed Probability that ', targetVar, '= 1 is', threshPredProb))

# Remove all observations where the target variable is missing
trainData <- na.omit(inputData)

# Get ready for training the classification tree model.
# 1. Get threshold for the misclassification error

# Specify target as a factor
trainData[[targetVar]] <- as.factor(trainData[[targetVar]])
print(paste('Categories of', targetVar))
print(levels(trainData[[targetVar]]))

# A logistic regression model with stepwise selection by AIC
myFormula <- paste(noquote(targetVar), '~')
qNotFirst = 0
for (col in c(intervalVars))
{
  if (qNotFirst == 1)
  {
    sepChar = ' + '
  }
  else
  {
    sepChar = ' '
    qNotFirst = 1
  }
  myFormula <- paste(myFormula, noquote(col), sep = sepChar)
}
print(myFormula)

fullModel <- glm(formula = myFormula, family = binomial(link = 'logit'), data = trainData)
myLogistic <- step(fullModel, direction = "both", trace = 1)

# See the model fit summary
print(summary(myLogistic))

# Calculate the prediction and save then to an external CSV file

# See the Misclassification Rate of the training data
fitted.prob <- predict(myLogistic, newdata = trainData, type = 'response')
fitted.results <- ifelse(fitted.prob >= threshPredProb, 1, 0)

# Save the predictions to CSV
write.csv(cbind(trainData, fitted.prob, fitted.results), paste(jsonFolder, analysisPrefix, '_r_pred.csv', sep = ''))

# Types of the columns
typeOfColumn <- as.data.frame(do.call(rbind, lapply(inputData, typeof)))
print(typeOfColumn)

# Invoke this function to generate the zip package
export_binary_model (
  targetVar = targetVar,
  intervalVars = intervalVars,
  nominalVars = NULL,
  nominalVarsLength = NULL,
  typeOfColumn = typeOfColumn,
  targetValue = trainData[[targetVar]],
  eventValue = 1,
  predEventProb = fitted.prob,
  eventProbThreshold = threshPredProb,
  algorithmCode = 1,
  modelObject = myLogistic,
  analysisFolder = analysisFolder,
  analysisPrefix = analysisPrefix,
  jsonFolder = jsonFolder,
  analysisName = 'Customer_Churn_stepwise_logistic',
  analysisDescription = 'Logistic Regression Model: Stepwise Selection by AIC',
  lenOutClass = 1,
  qDebug = 'Y')
