Rscript training.R

