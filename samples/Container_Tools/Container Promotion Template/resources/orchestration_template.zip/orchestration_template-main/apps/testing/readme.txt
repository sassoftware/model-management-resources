Add deployment descriptors for specific apps to this directory
