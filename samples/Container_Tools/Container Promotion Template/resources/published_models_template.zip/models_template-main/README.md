# models_template
This site provides the template for the Git repository needed for the published models integration repository.
